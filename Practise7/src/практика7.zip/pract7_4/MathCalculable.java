package pract7_4;

public interface MathCalculable {
    double pow(double a, double b);
    double ModuleComp(double a,double b);
    static double PI = 3.1415926535;
}
