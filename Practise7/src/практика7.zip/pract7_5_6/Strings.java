package pract7_5_6;

public interface Strings {
    public int SignsCount();
    public String NewString();
    public String InvertString();
}
