package pract7_8;

public interface Printable {
    void print();
}
