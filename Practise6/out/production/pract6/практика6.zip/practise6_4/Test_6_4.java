package practise6_4;

public class Test_6_4 {
    public static void main(String[] args) {
        Good Milk = new Good("Prostokvashino",120,500);
        System.out.printf("Price of Prostokvashino milk is: " +  Milk.getPrice());
    }
}
