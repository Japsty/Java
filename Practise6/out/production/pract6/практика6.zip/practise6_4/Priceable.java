package practise6_4;

public interface Priceable {
    int getPrice();
}
