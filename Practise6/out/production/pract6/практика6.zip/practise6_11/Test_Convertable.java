package practise6_11;

public class Test_Convertable {
    public static void main(String[] args) {
        fromCelsiustoFarenheit far = new fromCelsiustoFarenheit();
        far.convert();
        fromCelsiusToKelvin kel = new fromCelsiusToKelvin();
        kel.convert();
    }
}
