package practise6_11;

public interface Convertable {
    void convert();
}
