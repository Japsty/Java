package practise6__6_7_8_9;

public class Shop implements Printable {
    public void Print() {
        System.out.println("Shop");
    }
}
