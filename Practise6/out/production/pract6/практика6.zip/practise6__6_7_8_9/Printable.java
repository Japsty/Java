package practise6__6_7_8_9;

public interface Printable {
    void Print();
}
