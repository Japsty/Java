package practise6__6_7_8_9;

public class TestBook {
    public static void main(String[] args) {
        Book book_1 = new Book("The Witcher","Andrzej Sapkowski");
        book_1.Print();
    }
}
