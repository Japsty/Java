package practise6__6_7_8_9;

public class TestShop {
    public static void main(String[] args) {
        Shop shop_1 = new Shop();
        shop_1.Print();
    }
}
