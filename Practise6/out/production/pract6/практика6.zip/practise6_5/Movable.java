package practise6_5;

public interface Movable {
    void moveUp(int moveY);
    void moveDown(int moveY);
    void moveLeft(int moveX);
    void moveRight(int moveX);
}
