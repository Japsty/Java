package practise8_4;

import java.util.Scanner;

public class NumbersSumTest {
    public static void main(String[] args) {
        NumbersSum n = new NumbersSum();
        System.out.println(n.Sum(2,3,0,0));
    }
}
