package practise8_2;

public class NaturalNumber {
    int NumberOut(int numb)
    {
        System.out.println("Natural Numbers:");
        for(int i = 1; i<= numb; i++)
        {
            System.out.println(i);
        }
        return 0;
    };
}
